﻿using System;
namespace Linecomparision
{
    public class Program
    {
        public static void Main(string[] args)
        { 
            LineComp lineComp = new LineComp();
            lineComp.lc();

        }
    }
}